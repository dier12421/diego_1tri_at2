function setup() {
  Numero();
}
function Numero() {
  const input = prompt('Por favor, insira um número:');

  if (isNaN(input)) {
    console.log('Por favor, insira um número válido.');
  } else if (input > 100) {
    console.log('O número é maior que 100.');
  } else if (input == 100) {
    console.log('O número é igual a 100.');
  } else {
    console.log('O número não é maior que 100.');
  }
}